import type { EmisPageScan } from "./student-types";

/**
 * Runs only after the user signs in or requests a sync, and only on the official EMIS origin.
 * It reads rendered labels, tables and student-row links; it does not inspect
 * passwords, hidden inputs, browser storage, network APIs or application state.
 */
export const EMIS_PAGE_SCAN_SCRIPT = String.raw`(function () {
  var allowedOrigin = "https://emis.moedu.gov.iq";
  var clean = function (value) { return String(value || "").replace(/\s+/g, " ").trim(); };
  var text = function (node) { return clean(node && (node.innerText || node.textContent)); };
  var isVisible = function (node) {
    if (!node || !node.getBoundingClientRect) return false;
    var box = node.getBoundingClientRect();
    var style = window.getComputedStyle(node);
    return box.width > 0 && box.height > 0 && style.display !== "none" && style.visibility !== "hidden";
  };
  var sameOriginHttps = function (href) {
    try { var url = new URL(href, location.href); return url.protocol === "https:" && url.origin === allowedOrigin ? url.href : ""; }
    catch (_) { return ""; }
  };
  var pageUrl = location.href;
  if (location.origin !== allowedOrigin) {
    window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({
      type: "emis-page-scan", pageUrl: pageUrl, pageTitle: document.title,
      pageKind: "unknown", fields: {}, rows: [], profileLinks: [], nextPageUrls: [],
      warning: "افتح صفحة EMIS الرسمية قبل المزامنة."
    }));
    return;
  }
  var fields = {};
  var addField = function (key, value) {
    key = clean(key).replace(/[：:]$/, ""); value = clean(value);
    if (key && value && key.length < 100 && value.length < 1500 && !fields[key]) fields[key] = value;
  };
  var valueFromControl = function (element) {
    var target = element;
    if (target.control) target = target.control;
    if (target && typeof target.value === "string") return target.value;
    var sibling = element && element.nextElementSibling;
    if (sibling) return text(sibling);
    var parent = element && element.parentElement;
    if (parent) {
      var parentText = text(parent);
      var labelText = text(element);
      if (parentText && labelText && parentText.startsWith(labelText)) return parentText.slice(labelText.length);
    }
    return "";
  };
  Array.from(document.querySelectorAll("label, dt, th")).filter(isVisible).forEach(function (label) {
    var key = text(label);
    if (!key) return;
    var control = label.control || (label.htmlFor ? document.getElementById(label.htmlFor) : null);
    addField(key, valueFromControl(control || label));
  });
  Array.from(document.querySelectorAll("input:not([type='password']):not([type='hidden']):not([type='file']):not([type='submit']):not([type='button']), textarea, select")).filter(isVisible).forEach(function (control) {
    var key = "";
    if (control.id) {
      var label = Array.from(document.querySelectorAll("label")).find(function (item) { return item.htmlFor === control.id; });
      if (label) key = text(label);
    }
    if (!key) key = clean(control.getAttribute("aria-label") || control.getAttribute("placeholder") || control.getAttribute("name"));
    if (key && !/password|كلمة المرور|رمز التحقق/i.test(key)) addField(key, control.value);
  });
  Array.from(document.querySelectorAll("dl")).filter(isVisible).forEach(function (list) {
    Array.from(list.querySelectorAll("dt")).filter(isVisible).forEach(function (dt) {
      var dd = dt.nextElementSibling;
      if (dd && dd.tagName.toLowerCase() === "dd") addField(text(dt), text(dd));
    });
  });

  var rows = [];
  var profileLinks = [];
  var actionText = /^(تعديل|حذف|طباعة|نقل|edit|delete|remove|print|transfer)$/i;
  Array.from(document.querySelectorAll("table")).forEach(function (table) {
    if (!isVisible(table)) return;
    var trs = Array.from(table.querySelectorAll("tr")).filter(isVisible);
    var headerRow = trs.find(function (tr) { return tr.querySelectorAll("th").length > 0; });
    if (!headerRow) return;
    var headers = Array.from(headerRow.querySelectorAll("th,td")).map(function (cell, index) { return text(cell) || "حقل " + (index + 1); });
    trs.filter(function (tr) { return tr !== headerRow; }).forEach(function (tr) {
      var cells = Array.from(tr.querySelectorAll("td"));
      if (cells.length < 2) return;
      var rowFields = {};
      cells.forEach(function (cell, index) {
        var key = headers[index] || "حقل " + (index + 1);
        var value = text(cell);
        if (value) rowFields[key] = value;
      });
      if (Object.keys(rowFields).length < 2) return;
      var anchors = Array.from(tr.querySelectorAll("a[href]")).filter(isVisible);
      var candidate = anchors.find(function (a) {
        var label = clean(a.getAttribute("aria-label") || a.getAttribute("title") || text(a));
        var url = sameOriginHttps(a.href);
        return !!url && !actionText.test(label) && !/حذف|تعديل|طباعة|delete|edit|print/i.test(label + " " + a.href);
      });
      var profileUrl = candidate ? sameOriginHttps(candidate.href) : "";
      rows.push({ fields: rowFields, profileUrl: profileUrl || undefined });
      if (profileUrl) profileLinks.push(profileUrl);
    });
  });

  var nextPageUrls = [];
  Array.from(document.querySelectorAll("a[href], button[aria-label], button[title]")).filter(isVisible).forEach(function (element) {
    var label = clean(element.getAttribute("aria-label") || element.getAttribute("title") || text(element));
    if (!/(التالي|الصفحة التالية|next|›|»|\u203a|\u00bb)/i.test(label)) return;
    var url = sameOriginHttps(element.href || element.getAttribute("data-href") || "");
    if (url && url !== pageUrl) nextPageUrls.push(url);
  });
  var unique = function (items) { return Array.from(new Set(items)); };
  var pageKind = rows.length ? "list" : Object.keys(fields).length >= 2 ? "detail" : "unknown";
  var result = {
    type: "emis-page-scan", pageUrl: pageUrl, pageTitle: document.title,
    pageKind: pageKind, fields: fields, rows: rows,
    profileLinks: unique(profileLinks), nextPageUrls: unique(nextPageUrls)
  };
  window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(result));
})(); true;`;

export function parseEmisPageScan(value: string): EmisPageScan | null {
  try {
    const parsed = JSON.parse(value) as EmisPageScan;
    if (parsed.type !== "emis-page-scan" || typeof parsed.pageUrl !== "string") return null;
    return {
      type: "emis-page-scan",
      pageUrl: parsed.pageUrl,
      pageTitle: typeof parsed.pageTitle === "string" ? parsed.pageTitle : "",
      pageKind: parsed.pageKind === "list" || parsed.pageKind === "detail" ? parsed.pageKind : "unknown",
      fields: parsed.fields && typeof parsed.fields === "object" ? parsed.fields : {},
      rows: Array.isArray(parsed.rows) ? parsed.rows : [],
      profileLinks: Array.isArray(parsed.profileLinks) ? parsed.profileLinks : [],
      nextPageUrls: Array.isArray(parsed.nextPageUrls) ? parsed.nextPageUrls : [],
    };
  } catch {
    return null;
  }
}
