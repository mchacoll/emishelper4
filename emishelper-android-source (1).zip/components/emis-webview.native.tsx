import { forwardRef, useImperativeHandle, useRef } from "react";
import { StyleSheet, View } from "react-native";
import WebView, { type WebViewMessageEvent, type WebViewNavigation } from "react-native-webview";
import { EMIS_LOGIN_URL } from "@/lib/emis-webview-types";
import { EMIS_PAGE_SCAN_SCRIPT } from "@/lib/emis-page-reader";
import { EMIS_AUTO_DISCOVERY_SCRIPT } from "@/lib/emis-auto-discovery";
import type { EmisWebViewHandle, EmisWebViewProps } from "@/lib/emis-webview-types";

const EmisWebView = forwardRef<EmisWebViewHandle, EmisWebViewProps>(function EmisWebView(
  { onMessage, onUrlChange, onPageLoaded },
  ref,
) {
  const webViewRef = useRef<WebView>(null);
  useImperativeHandle(ref, () => ({
    scanCurrentPage: () => webViewRef.current?.injectJavaScript(EMIS_PAGE_SCAN_SCRIPT),
    inspectSession: () => webViewRef.current?.injectJavaScript(EMIS_AUTO_DISCOVERY_SCRIPT),
    navigateTo: (url: string) => {
      if (url.startsWith("https://emis.moedu.gov.iq/")) {
        webViewRef.current?.injectJavaScript(`window.location.href = ${JSON.stringify(url)}; true;`);
      }
    },
    reload: () => webViewRef.current?.reload(),
  }), []);

  const handleMessage = (event: WebViewMessageEvent) => {
    onMessage(event.nativeEvent.data, event.nativeEvent.url);
  };
  const handleNavigation = (state: WebViewNavigation) => onUrlChange(state.url);

  return (
    <View style={styles.frame}>
      <WebView
        ref={webViewRef}
        source={{ uri: EMIS_LOGIN_URL }}
        style={styles.webView}
        originWhitelist={["https://*"]}
        javaScriptEnabled
        domStorageEnabled
        sharedCookiesEnabled
        thirdPartyCookiesEnabled
        mixedContentMode="never"
        setSupportMultipleWindows={false}
        allowsBackForwardNavigationGestures
        onMessage={handleMessage}
        onNavigationStateChange={handleNavigation}
        onLoadEnd={onPageLoaded}
        onShouldStartLoadWithRequest={(request) => request.url.startsWith("https://")}
      />
    </View>
  );
});

const styles = StyleSheet.create({
  frame: { flex: 1, overflow: "hidden", borderRadius: 18, backgroundColor: "#FFFFFF" },
  webView: { flex: 1, backgroundColor: "#FFFFFF" },
});

export default EmisWebView;
