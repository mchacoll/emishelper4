import { Pressable, StyleSheet, View } from "react-native";
import { CairoText as Text } from "@/components/cairo-text";
import type { StudentRecord } from "@/lib/student-types";

export function StudentCard({
  record,
  index,
  onPress,
}: {
  record: StudentRecord;
  index: number;
  onPress: () => void;
}) {
  const preview = Object.entries(record.fields).find(([key, value]) =>
    value && !/اسم الأم|الاسم الرباعي|اللقب/.test(key),
  );
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
      <View style={styles.number}><Text style={styles.numberText}>{String(index + 1).padStart(2, "0")}</Text></View>
      <View style={styles.body}>
        <Text style={styles.name} numberOfLines={1}>{record.displayName || "سجل طالب"}</Text>
        <Text style={styles.meta} numberOfLines={1}>
          {record.studentNumber ? `رقم الطالب: ${record.studentNumber}` : `معرّف السجل: ${record.recordKey}`}
        </Text>
        {preview ? <Text style={styles.preview} numberOfLines={1}>{preview[0]}: {preview[1]}</Text> : null}
      </View>
      <Text style={styles.chevron}>‹</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: "row-reverse", alignItems: "center", gap: 12, borderRadius: 18, borderWidth: 1, borderColor: "#DCE9E7", backgroundColor: "#FFFFFF", paddingVertical: 14, paddingHorizontal: 14, marginBottom: 10 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.995 }] },
  number: { width: 42, height: 42, borderRadius: 14, backgroundColor: "#E4F1EF", alignItems: "center", justifyContent: "center" },
  numberText: { color: "#006D77", fontSize: 13, fontWeight: "800" },
  body: { flex: 1, alignItems: "flex-end", gap: 4 },
  name: { color: "#173B3D", fontSize: 16, fontWeight: "800", textAlign: "right" },
  meta: { color: "#718587", fontSize: 11, textAlign: "right" },
  preview: { color: "#537274", fontSize: 12, textAlign: "right" },
  chevron: { color: "#799194", fontSize: 24, lineHeight: 26 },
});
