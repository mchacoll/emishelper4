import { useCallback, useRef, useState } from "react";
import { useFonts } from "expo-font";
import * as Clipboard from "expo-clipboard";
import { SafeAreaView } from "react-native-safe-area-context";
import { ActivityIndicator, Platform, Pressable, ScrollView, StatusBar, StyleSheet, TextInput, View } from "react-native";
import { CairoText as Text } from "@/components/cairo-text";
import { parseEmisAutoDiscovery, type EmisAutoDiscovery } from "@/lib/emis-auto-discovery";
import EmisWebView from "@/components/emis-webview";
import type { EmisWebViewHandle } from "@/lib/emis-webview-types";
import { EMIS_ORIGIN } from "@/lib/emis-webview-types";
import { parseEmisPageScan } from "@/lib/emis-page-reader";
import { StudentCard } from "@/components/student-card";
import { StudentDetail } from "@/components/student-detail";
import { createStudentText, saveStudentExports } from "@/lib/student-export";
import { makeStudentRecord, mergeStudentRecords, requiredFieldValue, type EmisPageScan, type StudentRecord } from "@/lib/student-types";

type MainTab = "portal" | "students" | "export";
type SyncRun = {
  active: boolean;
  stage: "initial" | "list" | "profile";
  returnUrl: string;
  profileQueue: string[];
  listQueue: string[];
  visitedProfiles: Set<string>;
  visitedLists: Set<string>;
  profilesRead: number;
};

const REQUIRED_FIELDS = ["اسم الأم", "الاسم الرباعي", "اللقب"];
const COLORS = {
  ink: "#173B3D", muted: "#698184", teal: "#006D77", coral: "#E76F51",
  canvas: "#F2F8F7", border: "#DCE9E7", white: "#FFFFFF", paleTeal: "#E4F1EF", paleCoral: "#FFF0EA",
};

function Button({ title, onPress, tone = "primary", disabled = false, compact = false }: {
  title: string; onPress: () => void; tone?: "primary" | "soft" | "coral" | "outline"; disabled?: boolean; compact?: boolean;
}) {
  const buttonStyle = tone === "primary" ? styles.primaryButton : tone === "coral" ? styles.coralButton : tone === "outline" ? styles.outlineButton : styles.softButton;
  const textStyle = tone === "primary" || tone === "coral" ? styles.buttonTextLight : styles.buttonTextDark;
  return (
    <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress}
      style={({ pressed }) => [buttonStyle, compact && styles.compactButton, disabled && styles.disabledButton, pressed && !disabled && styles.pressedButton]}>
      <Text style={textStyle}>{title}</Text>
    </Pressable>
  );
}

function safePageUrl(value: string): string {
  try {
    const parsed = new URL(value);
    return parsed.origin === EMIS_ORIGIN ? parsed.href : "";
  } catch { return ""; }
}

function getMissingRequiredFields(record: StudentRecord): string[] {
  return REQUIRED_FIELDS.filter((name) => !requiredFieldValue(record.fields, name));
}

export default function HomeScreen() {
  useFonts({
    CairoRegular: require("../../assets/fonts/Cairo-Regular.ttf"),
    CairoBold: require("../../assets/fonts/Cairo-Bold.ttf"),
  });
  const [activeTab, setActiveTab] = useState<MainTab>("portal");
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [search, setSearch] = useState("");
  const [selectedStudent, setSelectedStudent] = useState<StudentRecord | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [message, setMessage] = useState("سجّل الدخول إلى EMIS؛ سيحاول التطبيق فتح قائمة الطلاب ومزامنتها تلقائيًا.");
  const [currentUrl, setCurrentUrl] = useState("https://emis.moedu.gov.iq/auth/login");
  const webViewRef = useRef<EmisWebViewHandle>(null);
  const syncRunRef = useRef<SyncRun | null>(null);
  const pendingAutoScanRef = useRef(false);
  const studentCountRef = useRef(0);
  const currentUrlRef = useRef("https://emis.moedu.gov.iq/auth/login");
  const autoNavigationAttemptedRef = useRef(false);
  const autoSyncStartedRef = useRef(false);

  const appendRecords = useCallback((incoming: StudentRecord[]) => {
    if (!incoming.length) return;
    setStudents((current) => {
      const next = mergeStudentRecords(current, incoming);
      studentCountRef.current = next.length;
      return next;
    });
  }, []);

  const finishSync = useCallback((run: SyncRun, finalMessage: string) => {
    const returnUrl = run.returnUrl;
    syncRunRef.current = null;
    pendingAutoScanRef.current = false;
    setSyncing(false);
    setMessage(finalMessage);
    if (returnUrl && safePageUrl(returnUrl) && currentUrl !== returnUrl) webViewRef.current?.navigateTo(returnUrl);
  }, [currentUrl]);

  const goToNextPage = useCallback((run: SyncRun) => {
    while (run.profileQueue.length) {
      const next = run.profileQueue.shift()!;
      if (safePageUrl(next) && !run.visitedProfiles.has(next)) {
        run.visitedProfiles.add(next);
        run.stage = "profile";
        run.profilesRead += 1;
        pendingAutoScanRef.current = true;
        setMessage(`قراءة ملف الطالب ${run.profilesRead}…`);
        webViewRef.current?.navigateTo(next);
        return;
      }
    }
    while (run.listQueue.length) {
      const next = run.listQueue.shift()!;
      if (safePageUrl(next) && !run.visitedLists.has(next)) {
        run.visitedLists.add(next);
        run.stage = "list";
        pendingAutoScanRef.current = true;
        setMessage(`قراءة صفحة أخرى من قائمة الطلاب (${run.visitedLists.size})…`);
        webViewRef.current?.navigateTo(next);
        return;
      }
    }
    const missingCount = students.filter((student) => getMissingRequiredFields(student).length > 0).length;
    const suffix = missingCount ? ` ${missingCount} سجلًا ما زالت به حقول ناقصة.` : "";
    finishSync(run, `اكتملت محاولة المزامنة. إجمالي السجلات الحالية: ${studentCountRef.current}.${suffix}`);
  }, [finishSync, students]);

  const handlePageScan = useCallback((scan: EmisPageScan) => {
    const run = syncRunRef.current;
    if (!run?.active) return;
    if (!safePageUrl(scan.pageUrl)) {
      finishSync(run, "لم تُقرأ الصفحة؛ افتح بوابة EMIS الرسمية ثم أعد المحاولة.");
      return;
    }

    if (run.stage === "profile") {
      if (Object.keys(scan.fields).length) appendRecords([makeStudentRecord(scan.fields, scan.pageUrl)]);
      goToNextPage(run);
      return;
    }

    if (scan.pageKind === "list" && scan.rows.length) {
      appendRecords(scan.rows.map((row, index) => makeStudentRecord(
        row.fields,
        row.profileUrl,
        row.profileUrl ? undefined : `row:${scan.pageUrl}#${index + 1}`,
      )));
      const discoveredProfiles = [...scan.profileLinks, ...scan.rows.map((row) => row.profileUrl || "")]
        .map(safePageUrl).filter(Boolean);
      for (const link of discoveredProfiles) {
        if (!run.visitedProfiles.has(link) && !run.profileQueue.includes(link)) run.profileQueue.push(link);
      }
      for (const link of scan.nextPageUrls.map(safePageUrl).filter(Boolean)) {
        if (!run.visitedLists.has(link) && !run.listQueue.includes(link)) run.listQueue.push(link);
      }
      if (!run.profileQueue.length && !run.listQueue.length) {
        finishSync(run, `قُرئت ${scan.rows.length} سجلات ظاهرة. لم تظهر روابط ملفات طلاب؛ راجع اكتمال الحقول من صفحة كل طالب.`);
        return;
      }
      goToNextPage(run);
      return;
    }

    if (run.stage === "initial" && scan.pageKind === "detail" && Object.keys(scan.fields).length) {
      appendRecords([makeStudentRecord(scan.fields, scan.pageUrl)]);
      finishSync(run, "قُرئ ملف الطالب المفتوح. للمزامنة الجماعية، ابدأ من قائمة الطلاب داخل EMIS.");
      return;
    }

    if (run.stage === "list") {
      goToNextPage(run);
      return;
    }

    finishSync(run, "لم أتعرف على قائمة الطلاب. افتحها داخل EMIS ثم اضغط مزامنة مرة أخرى.");
  }, [appendRecords, finishSync, goToNextPage]);

  const beginSync = useCallback((pageUrl: string, automatic = false) => {
    const baseUrl = safePageUrl(pageUrl);
    if (Platform.OS === "web" || !baseUrl || syncRunRef.current) return;
    autoSyncStartedRef.current = true;
    syncRunRef.current = {
      active: true, stage: "initial", returnUrl: baseUrl, profileQueue: [], listQueue: [],
      visitedProfiles: new Set(), visitedLists: new Set([baseUrl]), profilesRead: 0,
    };
    setSyncing(true);
    setActiveTab("portal");
    setMessage(automatic ? "تم رصد الدخول إلى EMIS؛ بدأت المزامنة تلقائيًا…" : "أفحص قائمة الطلاب الظاهرة في EMIS…");
    if (automatic) setTimeout(() => webViewRef.current?.scanCurrentPage(), 900);
    else webViewRef.current?.scanCurrentPage();
  }, []);

  const handleAutoDiscovery = useCallback((discovery: EmisAutoDiscovery) => {
    if (!discovery.authenticated) {
      if (discovery.loginForm) {
        autoNavigationAttemptedRef.current = false;
        autoSyncStartedRef.current = false;
      } else {
        setMessage("لم أتحقق من اكتمال الدخول بعد. أكمل الدخول وافتح قائمة الطلاب؛ لن تبدأ المزامنة قبل ظهور القائمة.");
      }
      return;
    }
    if (discovery.studentListDetected && !autoSyncStartedRef.current) {
      beginSync(discovery.pageUrl, true);
      return;
    }
    if (discovery.studentListUrl && discovery.studentListUrl !== discovery.pageUrl && !autoNavigationAttemptedRef.current) {
      autoNavigationAttemptedRef.current = true;
      setMessage("تم رصد تسجيل الدخول؛ يجري فتح قائمة الطلاب تلقائيًا…");
      webViewRef.current?.navigateTo(discovery.studentListUrl);
      return;
    }
    if (discovery.clickedStudentMenu) {
      setMessage("تم فتح قائمة الطلاب؛ يجري فحص الصفحة للبدء بالمزامنة…");
      return;
    }
    if (!autoSyncStartedRef.current && !autoNavigationAttemptedRef.current) {
      autoNavigationAttemptedRef.current = true;
      setMessage("تم تسجيل الدخول. إذا لم تظهر قائمة الطلاب تلقائيًا، افتحها مرة واحدة؛ ستبدأ المزامنة عند ظهورها.");
    }
  }, [beginSync]);

  const handleWebMessage = useCallback((raw: string, pageUrl?: string) => {
    const discovery = parseEmisAutoDiscovery(raw);
    if (discovery) {
      if (pageUrl && !safePageUrl(pageUrl)) return;
      handleAutoDiscovery(discovery);
      return;
    }
    const scan = parseEmisPageScan(raw);
    if (!scan || (pageUrl && !safePageUrl(pageUrl))) return;
    handlePageScan(scan);
  }, [handleAutoDiscovery, handlePageScan]);

  const handleUrlChange = useCallback((url: string) => {
    currentUrlRef.current = url;
    setCurrentUrl(url);
    if (!syncRunRef.current && safePageUrl(url)) {
      setTimeout(() => webViewRef.current?.inspectSession(), 700);
    }
  }, []);

  const handlePageLoaded = useCallback(() => {
    if (pendingAutoScanRef.current) {
      pendingAutoScanRef.current = false;
      setTimeout(() => webViewRef.current?.scanCurrentPage(), 500);
      return;
    }
    if (!syncRunRef.current && safePageUrl(currentUrlRef.current)) {
      setTimeout(() => webViewRef.current?.inspectSession(), 500);
    }
  }, []);

  const startSync = useCallback(() => {
    const baseUrl = safePageUrl(currentUrlRef.current);
    if (Platform.OS === "web") {
      setMessage("استخدم تطبيق Android لقراءة الصفحة المفتوحة داخل EMIS.");
      return;
    }
    if (!baseUrl) {
      setMessage("افتح بوابة EMIS الرسمية قبل المزامنة.");
      return;
    }
    beginSync(baseUrl);
  }, [beginSync]);

  const exportAll = useCallback(async () => {
    if (!students.length) { setMessage("لا توجد سجلات حالية لتصديرها."); return; }
    setExporting(true);
    try {
      const result = await saveStudentExports(students);
      setMessage(result.cancelled ? "أُلغي اختيار المجلد؛ لم تُحفظ ملفات." : `تم حفظ ملفي Excel وTXT محليًا: ${result.names.join(" و ")}`);
    } catch (error) {
      setMessage(error instanceof Error ? `تعذّر التصدير: ${error.message}` : "تعذّر إنشاء الملفات.");
    } finally { setExporting(false); }
  }, [students]);

  const copyAll = useCallback(async () => {
    if (!students.length) { setMessage("لا توجد سجلات حالية لنسخها."); return; }
    try {
      await Clipboard.setStringAsync(createStudentText(students));
      setMessage(`نُسخ نص ${students.length} سجلًا إلى الحافظة.`);
    } catch { setMessage("تعذّر النسخ إلى الحافظة على هذا الجهاز."); }
  }, [students]);

  const clearAll = useCallback(() => {
    setStudents([]);
    studentCountRef.current = 0;
    setConfirmClear(false);
    setMessage("مُسحت السجلات من ذاكرة التطبيق.");
  }, []);

  const filteredStudents = students.filter((student) => {
    const query = search.trim().toLowerCase();
    if (!query) return true;
    return [student.displayName, student.studentNumber, ...Object.values(student.fields)].join(" ").toLowerCase().includes(query);
  });

  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "bottom", "left", "right"]}>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.canvas} />
      <View style={styles.header}>
        <View style={styles.headerMeta}>
          <View style={styles.brandMark}><Text style={styles.brandMarkText}>EM</Text></View>
          <View style={styles.headerTitles}>
            <Text style={styles.overline}>مساعد محلي</Text>
            <Text style={styles.title}>مساعد EMIS</Text>
          </View>
        </View>
        <View style={styles.totalBadge}>
          <Text style={styles.totalValue}>{students.length}</Text>
          <Text style={styles.totalLabel}>طالب</Text>
        </View>
      </View>

      <View style={styles.privacyBanner}>
        <View style={styles.bannerDot} />
        <Text style={styles.privacyText}>حسابك التجريبي فقط · لا سجلات مصطنعة · لا إرسال تلقائي للملفات</Text>
      </View>

      <View style={styles.tabBar}>
        {([["portal", "بوابة EMIS"], ["students", `الطلاب (${students.length})`], ["export", "تصدير"]] as [MainTab, string][]).map(([tab, label]) => (
          <Pressable key={tab} onPress={() => setActiveTab(tab)} style={[styles.tab, activeTab === tab && styles.activeTab]}>
            <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>{label}</Text>
          </Pressable>
        ))}
      </View>

      <View style={[styles.portalScreen, activeTab !== "portal" && styles.hiddenScreen]}>
        <View style={styles.portalStatus}>
          <View style={[styles.statusDot, safePageUrl(currentUrl) ? styles.statusDotLive : styles.statusDotOff]} />
          <Text style={styles.portalStatusText} numberOfLines={1}>{safePageUrl(currentUrl) ? "بوابة EMIS الرسمية" : "اتصال غير متحقق"}</Text>
          <Pressable onPress={() => webViewRef.current?.reload()} style={styles.reloadButton}><Text style={styles.reloadText}>إعادة تحميل</Text></Pressable>
        </View>
        <View style={styles.webViewPanel}>
          <EmisWebView ref={webViewRef} onMessage={handleWebMessage} onUrlChange={handleUrlChange} onPageLoaded={handlePageLoaded} />
        </View>
        <View style={styles.actionRow}>
          <Button title={syncing ? "جارٍ فحص EMIS…" : "مزامنة الآن يدويًا"} onPress={startSync} disabled={syncing || Platform.OS === "web"} />
          {syncing ? <ActivityIndicator color={COLORS.teal} style={styles.syncSpinner} /> : null}
        </View>
        <Text style={styles.helperText}>بعد الدخول سيحاول التطبيق فتح القائمة تلقائيًا. إن لم يتعرف عليها، افتحها مرة واحدة؛ وسيبدأ التزامن عند ظهورها.</Text>
      </View>

      {activeTab === "students" && (
        <View style={styles.contentScreen}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionCopy}>
              <Text style={styles.sectionTitle}>سجلات الطلاب</Text>
              <Text style={styles.sectionSub}>{students.length ? `إجمالي السجلات: ${students.length}` : "لم تتم المزامنة بعد"}</Text>
            </View>
            <View style={styles.countBubble}><Text style={styles.countBubbleText}>{students.length}</Text></View>
          </View>
          <TextInput value={search} onChangeText={setSearch} placeholder="ابحث بالاسم أو الحقول…" placeholderTextColor="#849799" style={styles.searchInput} textAlign="right" accessibilityLabel="البحث في سجلات الطلاب" />
          {filteredStudents.length ? (
            <ScrollView contentContainerStyle={styles.studentList} keyboardShouldPersistTaps="handled">
              {filteredStudents.map((record, index) => <StudentCard key={record.recordKey} record={record} index={index} onPress={() => setSelectedStudent(record)} />)}
            </ScrollView>
          ) : (
            <View style={styles.emptyState}>
              <View style={styles.emptyIcon}><Text style={styles.emptyIconText}>≡</Text></View>
              <Text style={styles.emptyTitle}>{students.length ? "لا توجد نتائج" : "القائمة فارغة"}</Text>
              <Text style={styles.emptyCopy}>{students.length ? "جرّب كلمة بحث مختلفة." : "سجّل الدخول في EMIS؛ سيحاول التطبيق الوصول إلى القائمة ومزامنتها تلقائيًا."}</Text>
              {!students.length ? <Button compact title="العودة إلى بوابة EMIS" onPress={() => setActiveTab("portal")} tone="soft" /> : null}
            </View>
          )}
        </View>
      )}

      {activeTab === "export" && (
        <ScrollView style={styles.contentScreen} contentContainerStyle={styles.exportScreen}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionCopy}><Text style={styles.sectionTitle}>تصدير محلي</Text><Text style={styles.sectionSub}>لا تُرسل الملفات تلقائيًا لأي خدمة</Text></View>
            <View style={styles.exportGlyph}><Text style={styles.exportGlyphText}>⇩</Text></View>
          </View>
          <View style={styles.exportSummary}><Text style={styles.exportSummaryValue}>{students.length}</Text><Text style={styles.exportSummaryLabel}>سجل جاهز للتصدير</Text></View>
          <Button title={exporting ? "جارٍ تجهيز الملفات…" : "تصدير Excel وTXT"} onPress={exportAll} disabled={exporting || students.length === 0} />
          <Button title="نسخ النص الكامل" onPress={copyAll} tone="soft" disabled={students.length === 0} />
          {students.length ? <Button title="مسح سجلات الذاكرة" onPress={() => setConfirmClear(true)} tone="outline" /> : null}
          <View style={styles.exportNote}>
            <Text style={styles.exportNoteTitle}>كل طالب في سجل مستقل</Text>
            <Text style={styles.exportNoteBody}>يحتفظ Excel بصف منفصل لكل طالب، ويُفصل كل سجل في TXT بعنوان ومعرّف. الحقول غير المقروءة تبقى فارغة بدل نقل قيمة من سجل آخر.</Text>
          </View>
          {confirmClear ? (
            <View style={styles.confirmBox}>
              <Text style={styles.confirmTitle}>مسح السجلات من الذاكرة؟</Text>
              <Text style={styles.confirmBody}>لن تُحذف الملفات التي حفظتها في مجلد الهاتف.</Text>
              <View style={styles.confirmActions}><Button title="إلغاء" onPress={() => setConfirmClear(false)} tone="soft" compact /><Button title="مسح الآن" onPress={clearAll} tone="coral" compact /></View>
            </View>
          ) : null}
        </ScrollView>
      )}

      <View style={styles.messageBar}>
        <View style={styles.messageMark}><Text style={styles.messageMarkText}>i</Text></View>
        <Text style={styles.messageText} numberOfLines={3}>{message}</Text>
      </View>
      <StudentDetail record={selectedStudent} onClose={() => setSelectedStudent(null)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.canvas, paddingHorizontal: 16 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.canvas },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingTop: 6, paddingBottom: 11 },
  headerMeta: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  brandMark: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.teal },
  brandMarkText: { color: COLORS.white, fontSize: 14, fontFamily: "CairoBold" },
  headerTitles: { alignItems: "flex-end" },
  overline: { color: COLORS.coral, fontSize: 10, fontFamily: "CairoBold" },
  title: { color: COLORS.ink, fontSize: 20, fontFamily: "CairoBold" },
  totalBadge: { minWidth: 62, height: 48, paddingHorizontal: 11, borderRadius: 15, backgroundColor: COLORS.white, borderColor: COLORS.border, borderWidth: 1, alignItems: "center", justifyContent: "center", flexDirection: "row-reverse", gap: 5 },
  totalValue: { color: COLORS.teal, fontSize: 20, fontFamily: "CairoBold" },
  totalLabel: { color: COLORS.muted, fontSize: 11, fontFamily: "CairoRegular" },
  privacyBanner: { minHeight: 35, backgroundColor: "#E8F2F0", borderRadius: 11, paddingHorizontal: 10, flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: 10 },
  bannerDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: COLORS.teal },
  privacyText: { color: "#48696C", fontSize: 11, flex: 1, textAlign: "right", fontFamily: "CairoRegular" },
  tabBar: { flexDirection: "row-reverse", backgroundColor: "#E5EFED", borderRadius: 14, padding: 4, marginBottom: 10, gap: 4 },
  tab: { flex: 1, alignItems: "center", justifyContent: "center", minHeight: 39, borderRadius: 11, paddingHorizontal: 4 },
  activeTab: { backgroundColor: COLORS.teal },
  tabText: { color: "#5E7779", fontSize: 12, fontFamily: "CairoBold" },
  activeTabText: { color: COLORS.white },
  portalScreen: { flex: 1, minHeight: 240 },
  hiddenScreen: { display: "none" },
  portalStatus: { flexDirection: "row-reverse", alignItems: "center", gap: 7, paddingBottom: 8 },
  statusDot: { width: 8, height: 8, borderRadius: 5 },
  statusDotLive: { backgroundColor: COLORS.teal },
  statusDotOff: { backgroundColor: COLORS.coral },
  portalStatusText: { flex: 1, color: COLORS.ink, fontSize: 12, fontFamily: "CairoBold", textAlign: "right" },
  reloadButton: { paddingHorizontal: 10, paddingVertical: 5, backgroundColor: COLORS.white, borderColor: COLORS.border, borderWidth: 1, borderRadius: 9 },
  reloadText: { color: COLORS.teal, fontSize: 11, fontFamily: "CairoBold" },
  webViewPanel: { flex: 1, minHeight: 220, borderRadius: 18, overflow: "hidden", borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.white },
  actionRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, paddingTop: 9 },
  syncSpinner: { width: 24 },
  helperText: { color: COLORS.muted, fontSize: 11, textAlign: "right", paddingTop: 5, paddingBottom: 4, fontFamily: "CairoRegular" },
  contentScreen: { flex: 1, minHeight: 0 },
  sectionHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingTop: 4, paddingBottom: 13 },
  sectionCopy: { alignItems: "flex-end", gap: 2 },
  sectionTitle: { color: COLORS.ink, fontSize: 21, fontFamily: "CairoBold" },
  sectionSub: { color: COLORS.muted, fontSize: 12, fontFamily: "CairoRegular", textAlign: "right" },
  countBubble: { width: 43, height: 43, borderRadius: 15, backgroundColor: COLORS.paleTeal, alignItems: "center", justifyContent: "center" },
  countBubbleText: { color: COLORS.teal, fontSize: 17, fontFamily: "CairoBold" },
  searchInput: { height: 46, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.white, paddingHorizontal: 14, color: COLORS.ink, fontFamily: "CairoRegular", marginBottom: 12 },
  studentList: { paddingBottom: 16 },
  emptyState: { flex: 1, minHeight: 250, alignItems: "center", justifyContent: "center", paddingHorizontal: 24, gap: 10 },
  emptyIcon: { width: 54, height: 54, borderRadius: 19, backgroundColor: COLORS.paleTeal, alignItems: "center", justifyContent: "center" },
  emptyIconText: { color: COLORS.teal, fontSize: 28 },
  emptyTitle: { color: COLORS.ink, fontSize: 18, fontFamily: "CairoBold" },
  emptyCopy: { color: COLORS.muted, textAlign: "center", lineHeight: 22, fontSize: 13, fontFamily: "CairoRegular" },
  exportScreen: { gap: 11, paddingBottom: 18 },
  exportGlyph: { width: 43, height: 43, borderRadius: 15, backgroundColor: COLORS.paleCoral, alignItems: "center", justifyContent: "center" },
  exportGlyphText: { color: COLORS.coral, fontSize: 24, fontWeight: "800" },
  exportSummary: { minHeight: 88, borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.white, alignItems: "center", justifyContent: "center", gap: 0 },
  exportSummaryValue: { color: COLORS.teal, fontSize: 30, fontFamily: "CairoBold" },
  exportSummaryLabel: { color: COLORS.muted, fontSize: 12, fontFamily: "CairoRegular" },
  primaryButton: { minHeight: 47, paddingHorizontal: 16, borderRadius: 14, backgroundColor: COLORS.teal, alignItems: "center", justifyContent: "center", flex: 1 },
  softButton: { minHeight: 47, paddingHorizontal: 16, borderRadius: 14, backgroundColor: COLORS.paleTeal, alignItems: "center", justifyContent: "center", flex: 1 },
  coralButton: { minHeight: 47, paddingHorizontal: 16, borderRadius: 14, backgroundColor: COLORS.coral, alignItems: "center", justifyContent: "center", flex: 1 },
  outlineButton: { minHeight: 44, paddingHorizontal: 16, borderRadius: 14, borderWidth: 1, borderColor: "#ECC5B7", backgroundColor: COLORS.white, alignItems: "center", justifyContent: "center", flex: 1 },
  compactButton: { minHeight: 38, paddingHorizontal: 14 },
  disabledButton: { opacity: 0.42 },
  pressedButton: { opacity: 0.78 },
  buttonTextLight: { color: COLORS.white, fontSize: 14, fontFamily: "CairoBold", textAlign: "center" },
  buttonTextDark: { color: COLORS.teal, fontSize: 14, fontFamily: "CairoBold", textAlign: "center" },
  exportNote: { padding: 14, borderRadius: 16, backgroundColor: "#E8F2F0", gap: 5 },
  exportNoteTitle: { color: COLORS.ink, fontSize: 14, fontFamily: "CairoBold", textAlign: "right" },
  exportNoteBody: { color: "#587376", fontSize: 12, lineHeight: 21, fontFamily: "CairoRegular", textAlign: "right" },
  confirmBox: { borderWidth: 1, borderColor: "#F1C7B9", backgroundColor: "#FFF9F6", borderRadius: 16, padding: 13, gap: 6 },
  confirmTitle: { color: COLORS.ink, fontSize: 15, fontFamily: "CairoBold", textAlign: "right" },
  confirmBody: { color: COLORS.muted, fontSize: 12, fontFamily: "CairoRegular", textAlign: "right" },
  confirmActions: { flexDirection: "row-reverse", gap: 8, paddingTop: 5 },
  messageBar: { minHeight: 46, flexDirection: "row-reverse", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 8, paddingBottom: 2 },
  messageMark: { width: 20, height: 20, borderRadius: 7, backgroundColor: COLORS.paleTeal, alignItems: "center", justifyContent: "center" },
  messageMarkText: { color: COLORS.teal, fontSize: 12, fontFamily: "CairoBold" },
  messageText: { flex: 1, color: COLORS.muted, fontSize: 11, lineHeight: 17, textAlign: "right", fontFamily: "CairoRegular" },
});
