import { Platform } from "react-native";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import * as XLSX from "xlsx";
import { isRequiredStudentField, requiredFieldValue, type StudentRecord } from "./student-types";

const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const REQUIRED_FIELDS = ["اسم الأم", "الاسم الرباعي", "اللقب"];

function buildRows(records: StudentRecord[]): Record<string, string>[] {
  const fieldNames = Array.from(new Set([
    ...REQUIRED_FIELDS,
    ...records.flatMap((record) => Object.keys(record.fields).filter((name) => !isRequiredStudentField(name))),
  ]));
  return records.map((record) => ({
    "معرّف السجل": record.recordKey,
    "رقم الطالب": record.studentNumber,
    "اسم الطالب": record.displayName,
    ...Object.fromEntries(fieldNames.map((name) => [
      name,
      REQUIRED_FIELDS.includes(name) ? requiredFieldValue(record.fields, name) : record.fields[name] ?? "",
    ])),
  }));
}

export function createStudentText(records: StudentRecord[]): string {
  return records.map((record, index) => {
    const lines = [
      `===== الطالب ${index + 1}: ${record.displayName} =====`,
      `معرّف السجل: ${record.recordKey}`,
      `رقم الطالب: ${record.studentNumber}`,
    ];
    const fieldNames = Array.from(new Set([
      ...REQUIRED_FIELDS,
      ...Object.keys(record.fields).filter((name) => !isRequiredStudentField(name)),
    ]));
    for (const key of fieldNames) {
      lines.push(`${key}: ${REQUIRED_FIELDS.includes(key) ? requiredFieldValue(record.fields, key) : record.fields[key] ?? ""}`);
    }
    return lines.join("\n");
  }).join("\n\n----------------------------------------\n\n");
}

function makeWorkbookBase64(records: StudentRecord[]): string {
  const rows = buildRows(records);
  const headers = Array.from(new Set(rows.flatMap((row) => Object.keys(row))));
  const sheet = XLSX.utils.json_to_sheet(rows, { header: headers });
  sheet["!cols"] = headers.map((header) => ({ wch: Math.min(Math.max(header.length + 8, 14), 36) }));
  (sheet as XLSX.WorkSheet & { "!rtl"?: boolean })["!rtl"] = true;
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, "الطلاب");
  return XLSX.write(workbook, { bookType: "xlsx", type: "base64" });
}

function makeFileStem(): string {
  const date = new Date();
  const stamp = [date.getFullYear(), String(date.getMonth() + 1).padStart(2, "0"), String(date.getDate()).padStart(2, "0"), "-", String(date.getHours()).padStart(2, "0"), String(date.getMinutes()).padStart(2, "0")].join("");
  return `emis-students-${stamp}`;
}

function downloadOnWeb(fileName: string, content: BlobPart, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export async function saveStudentExports(records: StudentRecord[]): Promise<{ cancelled: boolean; names: string[] }> {
  if (!records.length) throw new Error("لا توجد سجلات لتصديرها.");
  const stem = makeFileStem();
  const xlsxName = `${stem}.xlsx`;
  const txtName = `${stem}.txt`;
  const xlsxBase64 = makeWorkbookBase64(records);
  const text = createStudentText(records);

  if (Platform.OS === "web") {
    const workbook = XLSX.utils.book_new();
    const sheet = XLSX.utils.json_to_sheet(buildRows(records));
    (sheet as XLSX.WorkSheet & { "!rtl"?: boolean })["!rtl"] = true;
    XLSX.utils.book_append_sheet(workbook, sheet, "الطلاب");
    const bytes = XLSX.write(workbook, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
    downloadOnWeb(xlsxName, bytes, XLSX_MIME);
    downloadOnWeb(txtName, text, "text/plain;charset=utf-8");
    return { cancelled: false, names: [xlsxName, txtName] };
  }

  const saf = FileSystem.StorageAccessFramework;
  if (Platform.OS === "android" && saf) {
    const permission = await saf.requestDirectoryPermissionsAsync();
    if (!permission.granted) return { cancelled: true, names: [] };
    const xlsxUri = await saf.createFileAsync(permission.directoryUri, xlsxName, XLSX_MIME);
    await saf.writeAsStringAsync(xlsxUri, xlsxBase64, { encoding: FileSystem.EncodingType.Base64 });
    const txtUri = await saf.createFileAsync(permission.directoryUri, txtName, "text/plain");
    await saf.writeAsStringAsync(txtUri, text, { encoding: FileSystem.EncodingType.UTF8 });
    return { cancelled: false, names: [xlsxName, txtName] };
  }

  const directory = FileSystem.documentDirectory;
  if (!directory) throw new Error("تعذّر العثور على مجلد محلي لحفظ الملفات.");
  const xlsxUri = `${directory}${xlsxName}`;
  const txtUri = `${directory}${txtName}`;
  await FileSystem.writeAsStringAsync(xlsxUri, xlsxBase64, { encoding: FileSystem.EncodingType.Base64 });
  await FileSystem.writeAsStringAsync(txtUri, text, { encoding: FileSystem.EncodingType.UTF8 });
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(xlsxUri, { mimeType: XLSX_MIME, dialogTitle: "حفظ ملف Excel" });
    await Sharing.shareAsync(txtUri, { mimeType: "text/plain", dialogTitle: "حفظ ملف TXT" });
  }
  return { cancelled: false, names: [xlsxName, txtName] };
}
