import { Modal, Pressable, ScrollView, StyleSheet, View } from "react-native";
import { CairoText as Text } from "@/components/cairo-text";
import { isRequiredStudentField, requiredFieldValue, type StudentRecord } from "@/lib/student-types";

const REQUIRED_FIELDS = ["اسم الأم", "الاسم الرباعي", "اللقب"];

export function StudentDetail({
  record,
  onClose,
}: {
  record: StudentRecord | null;
  onClose: () => void;
}) {
  if (!record) return null;
  const otherFields = Object.entries(record.fields).filter(([key, value]) => value.trim() && !isRequiredStudentField(key));
  const fields: [string, string][] = [
    ...REQUIRED_FIELDS.map((name) => [name, requiredFieldValue(record.fields, name)] as [string, string]),
    ...otherFields,
  ];
  return (
    <Modal animationType="slide" transparent visible onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <View style={styles.header}>
            <Pressable onPress={onClose} accessibilityRole="button" style={styles.close}>
              <Text style={styles.closeText}>إغلاق</Text>
            </Pressable>
            <View style={styles.headerCopy}>
              <Text style={styles.kicker}>سجل مستقل</Text>
              <Text style={styles.title} numberOfLines={2}>{record.displayName}</Text>
              <Text style={styles.idText}>رقم الطالب: {record.studentNumber || "غير متوفر"}</Text>
              <Text selectable style={styles.idText}>معرّف السجل: {record.recordKey}</Text>
            </View>
          </View>
          <ScrollView contentContainerStyle={styles.fields}>
            {fields.length ? fields.map(([key, value]) => (
              <View key={`${record.recordKey}-${key}`} style={styles.field}>
                <Text style={styles.label}>{key}</Text>
                <Text selectable style={[styles.value, !value && styles.missingValue]}>{value || "غير متوفر أو لم يُقرأ"}</Text>
              </View>
            )) : <Text style={styles.empty}>لا توجد حقول مقروءة في هذا السجل.</Text>}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(30, 18, 70, 0.48)" },
  sheet: { maxHeight: "88%", minHeight: "58%", backgroundColor: "#FAF8FF", borderTopLeftRadius: 26, borderTopRightRadius: 26, paddingTop: 22, paddingHorizontal: 18, paddingBottom: 20 },
  header: { flexDirection: "row-reverse", alignItems: "flex-start", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: "#E4DFF7", paddingBottom: 17 },
  headerCopy: { flex: 1, alignItems: "flex-end", gap: 4 },
  kicker: { fontSize: 11, color: "#EE5A8A", fontWeight: "800" },
  title: { fontSize: 21, color: "#2A1B5E", fontWeight: "800", textAlign: "right" },
  idText: { fontSize: 11, color: "#7A7396", textAlign: "right" },
  close: { backgroundColor: "#ECE7FF", paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, marginLeft: 12 },
  closeText: { color: "#5B3FD6", fontSize: 12, fontWeight: "800" },
  fields: { paddingTop: 14, paddingBottom: 24, gap: 9 },
  field: { backgroundColor: "#FFFFFF", borderColor: "#E4DFF7", borderWidth: 1, borderRadius: 14, paddingVertical: 11, paddingHorizontal: 13, gap: 5 },
  label: { color: "#7A7396", fontSize: 12, textAlign: "right" },
  value: { color: "#2A1B5E", fontSize: 15, fontWeight: "600", textAlign: "right", writingDirection: "rtl" },
  missingValue: { color: "#B83A67", fontFamily: "CairoBold" },
  empty: { color: "#7A7396", textAlign: "right", paddingVertical: 20 },
});
